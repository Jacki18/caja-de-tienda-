@echo off
chcp 65001 >nul
cd /d "%~dp0"

:: Verificar Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Instalando Python...
    powershell -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.0/python-3.12.0-amd64.exe' -OutFile '%TEMP%\python-installer.exe'"
    start /wait %TEMP%\python-installer.exe /quiet InstallAllUsers=1 PrependPath=1
    set "PATH=%PATH%;C:\Program Files\Python312;C:\Program Files\Python312\Scripts"
    del %TEMP%\python-installer.exe
    timeout /t 3 >nul
)

:: Instalar dependencias
python -m pip install -r requirements.txt --quiet

:: Crear/actualizar el acceso directo del Escritorio (con el logo)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0crear_acceso_directo.ps1" >nul 2>&1

:: Ejecutar sin consola
start "" pythonw "%~dp0TiendaPro.py"
