# Crea el acceso directo "TiendaPro" en el Escritorio con el logo de la tienda.
$ErrorActionPreference = "Stop"
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path

$pyw = (Get-Command pythonw.exe -ErrorAction SilentlyContinue).Source
if (-not $pyw) { $pyw = (Get-Command pyw.exe -ErrorAction SilentlyContinue).Source }
if (-not $pyw) { Write-Host "No se encontro Python. Instalalo desde python.org y vuelve a intentar."; exit 1 }

$escritorio = [Environment]::GetFolderPath("Desktop")
$ws = New-Object -ComObject WScript.Shell
$acceso = $ws.CreateShortcut((Join-Path $escritorio "TiendaPro.lnk"))
$acceso.TargetPath = $pyw
$acceso.Arguments = '"' + (Join-Path $dir "TiendaPro.py") + '"'
$acceso.WorkingDirectory = $dir
$acceso.IconLocation = (Join-Path $dir "assets\icono.ico") + ",0"
$acceso.Description = "TiendaPro - Punto de venta"
$acceso.Save()
Write-Host "Acceso directo creado en: $escritorio"
