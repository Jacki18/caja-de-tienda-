"""
TiendaPro - Sistema de punto de venta

INSTALAR: pip install -r requirements.txt
EJECUTAR: python TiendaPro.py   (o doble clic en ABRIR.bat)
"""
from src.ui.app import main

if __name__ == "__main__":
    main()
