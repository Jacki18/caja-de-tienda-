"""Pruebas de la lógica de negocio. Ejecutar:  python -m unittest discover -s tests -v"""
import tempfile
import unittest
from pathlib import Path

from src import config
from src.database import Database, conectar
from src.repositories import (CompraRepository, ProductoRepository, ReporteRepository,
                              UsuarioRepository, VentaRepository)
from src.security import esta_hasheada
from src.utils import numero_a_texto, parse_decimal


class BaseConBD(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        config.DB_PATH = Path(self._tmp.name) / "prueba.db"
        Database()

    def tearDown(self):
        self._tmp.cleanup()

    def crear_arroz(self):
        ProductoRepository.agregar("ARR1", "", "Arroz", "Comida", 5.0, 0, "kg", 0, 5, "admin")
        return ProductoRepository.obtener_por_codigo("ARR1")


class TestUtils(unittest.TestCase):
    def test_decimales_con_coma_o_punto(self):
        self.assertEqual(parse_decimal("4,5"), 4.5)
        self.assertEqual(parse_decimal(" 5.5 "), 5.5)

    def test_vacio_y_basura(self):
        self.assertEqual(parse_decimal("", vacio=0.0), 0.0)
        for malo in ("", "abc", "nan", "inf"):
            with self.assertRaises(ValueError):
                parse_decimal(malo)

    def test_numero_a_texto(self):
        self.assertEqual(numero_a_texto(4.5), "4.5")
        self.assertEqual(numero_a_texto(12.0), "12")
        self.assertEqual(numero_a_texto(None), "0")


class TestUsuarios(BaseConBD):
    def test_login_y_hash(self):
        self.assertIsNotNone(UsuarioRepository.login("admin", "admin123"))
        self.assertIsNone(UsuarioRepository.login("admin", "mala"))
        with conectar() as c:
            self.assertTrue(esta_hasheada(c.execute("SELECT clave FROM usuarios WHERE usuario='admin'").fetchone()[0]))

    def test_migra_clave_en_texto_plano(self):
        with conectar() as c:
            c.execute("UPDATE usuarios SET clave='vieja123' WHERE usuario='duena'")
        Database()
        self.assertIsNotNone(UsuarioRepository.login("duena", "vieja123"))

    def test_cambiar_clave(self):
        UsuarioRepository.cambiar_clave("admin", "nueva!")
        self.assertIsNone(UsuarioRepository.login("admin", "admin123"))
        self.assertIsNotNone(UsuarioRepository.login("admin", "nueva!"))


class TestComprasYGanancias(BaseConBD):
    def test_costo_promedio_y_stock(self):
        a = self.crear_arroz()
        CompraRepository.registrar(a.id, 50, 4.00, "2026-09-01", "Mayorista")
        CompraRepository.registrar(a.id, 30, 4.50, "2026-09-15", "Mayorista", nuevo_precio=5.5)
        a = ProductoRepository.obtener_por_id(a.id)
        self.assertEqual(a.stock, 80)
        self.assertAlmostEqual(a.costo, 4.1875, places=4)
        self.assertEqual(a.precio, 5.5)
        fechas = [f["fecha"] for f in CompraRepository.obtener("arroz")]
        self.assertEqual(fechas, ["2026-09-15", "2026-09-01"])

    def test_ganancia_de_venta_y_costo_historico(self):
        a = self.crear_arroz()
        CompraRepository.registrar(a.id, 10, 4.0, "2026-09-01")
        item = {"producto_id": a.id, "cantidad": 2.5, "precio_unitario": 5.5, "subtotal": 13.75}
        boleta, _ = VentaRepository.registrar([item], "Efectivo", 0, "admin")
        self.assertIsNotNone(boleta)
        CompraRepository.registrar(a.id, 10, 9.0, "2026-09-20")      # sube el costo después
        fila = ReporteRepository.ganancias("2000-01-01", "2999-01-01")[0]
        self.assertAlmostEqual(fila[3], 13.75)
        self.assertAlmostEqual(VentaRepository.obtener_todas()[0]["ganancia"], 2.5 * (5.5 - 4.0))

    def test_no_se_vende_mas_que_el_stock(self):
        a = self.crear_arroz()
        CompraRepository.registrar(a.id, 1, 4.0, "2026-09-01")
        item = {"producto_id": a.id, "cantidad": 5, "precio_unitario": 5.5, "subtotal": 27.5}
        boleta, msg = VentaRepository.registrar([item], "Efectivo", 0, "admin")
        self.assertIsNone(boleta)
        self.assertEqual(ProductoRepository.obtener_por_id(a.id).stock, 1)

    def test_no_se_elimina_producto_con_historial(self):
        a = self.crear_arroz()
        CompraRepository.registrar(a.id, 5, 4.0, "2026-09-01")
        ok, _ = ProductoRepository.eliminar(a.id)
        self.assertFalse(ok)

    def test_busqueda_por_codigo_exacto(self):
        a = self.crear_arroz()
        self.assertEqual(ProductoRepository.obtener_por_codigo("ARR1").id, a.id)
        self.assertIsNone(ProductoRepository.obtener_por_codigo("NOEXISTE"))


if __name__ == "__main__":
    unittest.main()
