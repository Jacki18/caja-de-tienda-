"""Componentes de interfaz reutilizables."""
import sys
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk

import customtkinter as ctk

from src.config import ASSETS_DIR, Color
from src.utils import parse_decimal


class TemaManager:
    @staticmethod
    def cambiar():
        modo_actual = ctk.get_appearance_mode()
        if modo_actual == "Dark":
            ctk.set_appearance_mode("Light")
            return "Light"
        else:
            ctk.set_appearance_mode("Dark")
            return "Dark"


class BotonTema(ctk.CTkButton):
    def __init__(self, parent):
        super().__init__(parent, text="", width=40, height=40, corner_radius=8,
                         fg_color=Color.PRIMARIO, hover_color=Color.PRIMARIO_HOVER,
                         font=ctk.CTkFont(size=20),
                         command=self.cambiar_tema)
        self.modo = "Dark"

    def cambiar_tema(self):
        self.modo = TemaManager.cambiar()
        if self.modo == "Light":
            self.configure(text="☀", fg_color=Color.SOL, hover_color=Color.SOL_HOVER)
        else:
            self.configure(text="☾", fg_color=Color.PRIMARIO, hover_color=Color.PRIMARIO_HOVER)


class TablaBase(ttk.Treeview):
    def __init__(self, parent, columns, widths=None, height=20):
        super().__init__(parent, columns=columns, show="headings", height=height)
        style = ttk.Style()
        style.theme_use("default")
        style.configure("Treeview", background=Color.SUPERFICIE, foreground=Color.TEXTO,
                        fieldbackground=Color.SUPERFICIE, borderwidth=0, font=("Segoe UI", 12))
        style.configure("Treeview.Heading", background=Color.BORDE, foreground=Color.TEXTO,
                        relief="flat", font=("Segoe UI", 12, "bold"))
        style.map("Treeview", background=[("selected", Color.PRIMARIO)], foreground=[("selected", "white")])
        for i, col in enumerate(columns):
            self.heading(col, text=col.upper())
            self.column(col, width=widths[i] if widths else 100)


class DialogoBase(ctk.CTkToplevel):
    """Ventana modal centrada, con el icono de la aplicación."""
    def __init__(self, titulo, ancho=500, alto=500):
        super().__init__()
        self.title(titulo)
        self.geometry(f"{ancho}x{alto}")
        self.transient(self.master)
        self.grab_set()
        self.update_idletasks()
        x = (self.winfo_screenwidth() // 2) - (ancho // 2)
        y = (self.winfo_screenheight() // 2) - (alto // 2)
        self.geometry(f"+{x}+{y}")
        aplicar_icono(self)


class ModernCard(ctk.CTkFrame):
    """Tarjeta moderna con sombra y bordes redondeados"""
    def __init__(self, parent, **kwargs):
        fg_color = kwargs.pop("fg_color", Color.SUPERFICIE)
        border_color = kwargs.pop("border_color", Color.BORDE)
        super().__init__(parent, fg_color=fg_color, border_color=border_color,
                         border_width=1, corner_radius=16, **kwargs)


class ModernEntry(ctk.CTkEntry):
    """Entry moderno con estilo consistente"""
    def __init__(self, parent, placeholder="", show=None, **kwargs):
        super().__init__(parent, placeholder_text=placeholder, show=show,
                         font=ctk.CTkFont(size=14), height=48,
                         fg_color=Color.FONDO_INPUT, border_color=Color.BORDE,
                         corner_radius=10, **kwargs)


def aplicar_icono(ventana):
    """Pone el logo de la tienda en la ventana y la barra de tareas."""
    ico = ASSETS_DIR / "icono.ico"
    png = ASSETS_DIR / "icono.png"

    def _aplicar():
        try:
            if sys.platform.startswith("win") and ico.exists():
                ventana.iconbitmap(str(ico))
            elif png.exists():
                foto = tk.PhotoImage(file=str(png))
                ventana.iconphoto(True, foto)
                ventana._foto_icono = foto      # evita que Python libere la imagen
        except Exception:
            pass                                 # el icono es decorativo: nunca debe romper la app

    _aplicar()
    # CustomTkinter vuelve a poner su icono ~200 ms después de abrir la ventana en Windows.
    # Lo reaplicamos después para que quede el nuestro.
    ventana.after(350, _aplicar)


def crear_campo(padre, etiqueta, variable, numerico=False):
    """Etiqueta + entrada de texto. Los campos numéricos se seleccionan completos al entrar,
    así lo que escribes reemplaza el valor (antes "0.00" + escribir 4 daba "40.00")."""
    ctk.CTkLabel(padre, text=etiqueta, font=ctk.CTkFont(size=14)).pack(anchor="w")
    entrada = ctk.CTkEntry(padre, textvariable=variable, font=ctk.CTkFont(size=14), height=35)
    entrada.pack(fill="x", pady=(0, 10))
    if numerico:
        entrada.bind("<FocusIn>", lambda e: entrada.after(10, lambda: entrada.select_range(0, "end")))
    return entrada


def pedir_numero(titulo, mensaje, parent=None, minimo=None):
    """Pide un número (acepta 4,5 y 4.5). Devuelve None si se cancela."""
    while True:
        texto = simpledialog.askstring(titulo, mensaje, parent=parent)
        if texto is None:
            return None
        try:
            valor = parse_decimal(texto)
        except ValueError:
            messagebox.showerror("Número inválido", "Escribe un número, por ejemplo 4.5", parent=parent)
            continue
        if minimo is not None and valor < minimo:
            messagebox.showerror("Valor inválido", f"El valor debe ser mayor o igual a {minimo:g}.", parent=parent)
            continue
        return valor
