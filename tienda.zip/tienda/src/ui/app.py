"""Ventana principal de la aplicación."""
import sys
from datetime import datetime, timedelta
from tkinter import TclError, messagebox

import customtkinter as ctk

from src.config import APP_ID, MONEDA, ROLES, Color
from src.database import Database
from src.repositories import (CompraRepository, ConfigRepository, LicenciaRepository, ProductoRepository,
                              ReporteRepository, UsuarioRepository, VentaRepository)
from src.ui.components import BotonTema, ModernCard, TablaBase, aplicar_icono, pedir_numero
from src.ui.dialogs import BoletaDialog, CompraDialog, LoginDialog, ProductoDialog, UsuarioDialog


class TiendaRapidaApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Tienda Rápida - Punto de Venta")
        self.geometry("1600x900")
        try:
            self.state("zoomed")          # maximizada (solo Windows)
        except TclError:
            pass
        self.minsize(1200, 700)
        self.usuario_actual = None
        self.items_venta = []
        self.metodo_pago = "Efectivo"
        self.sugerencias = []
        self.sugerencia_seleccionada = -1

        aplicar_icono(self)

        Database()

        self.withdraw()
        LoginDialog(self, self._on_login_success)

    def _on_login_success(self, usuario):
        self.usuario_actual = usuario
        self.deiconify()
        self._construir_interfaz()
        self._refrescar_todo()

    def _construir_interfaz(self):
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=4)
        self.grid_columnconfigure(2, weight=2)
        self.grid_rowconfigure(0, weight=1)
        self._crear_menu_lateral()
        self._crear_area_central()
        self._crear_panel_carrito()

    def _crear_menu_lateral(self):
        self.menu_lateral = ctk.CTkFrame(self, corner_radius=0, width=220, fg_color=Color.SUPERFICIE)
        self.menu_lateral.grid(row=0, column=0, sticky="nsew")
        self.menu_lateral.grid_rowconfigure(1, weight=1)

        ctk.CTkLabel(self.menu_lateral, text="Tienda Rápida",
                     font=ctk.CTkFont(size=20, weight="bold"), text_color=Color.PRIMARIO).pack(padx=20, pady=30)

        self.botones_menu = {}
        for clave, texto in self._entradas_menu():
            btn = ctk.CTkButton(self.menu_lateral, text=texto, fg_color="transparent",
                                text_color=Color.TEXTO_SUAVE, hover_color=Color.BORDE, anchor="w",
                                font=ctk.CTkFont(size=16, weight="bold"), height=50,
                                command=lambda c=clave: self.cambiar_pagina(c))
            btn.pack(fill="x", padx=10, pady=3)
            self.botones_menu[clave] = btn

        self.btn_tema = BotonTema(self.menu_lateral)
        self.btn_tema.pack(side="bottom", padx=10, pady=5)

        ctk.CTkLabel(self.menu_lateral, text=f"{self.usuario_actual['nombre']}\n({ROLES[self.usuario_actual['rol']]['nombre']})",
                     font=ctk.CTkFont(size=11), text_color=Color.EXITO).pack(side="bottom", pady=10)

    def _crear_area_central(self):
        self.area_central = ctk.CTkFrame(self, fg_color="transparent")
        self.area_central.grid(row=0, column=1, sticky="nsew", padx=20, pady=20)
        self.area_central.grid_columnconfigure(0, weight=1)
        self.area_central.grid_rowconfigure(1, weight=1)

        self.txt_buscar = ctk.CTkEntry(self.area_central, placeholder_text="Buscar producto por nombre o código de barras...",
                                        height=50, font=ctk.CTkFont(size=14), fg_color=Color.SUPERFICIE, border_color=Color.BORDE)
        self.txt_buscar.grid(row=0, column=0, sticky="ew", pady=(0, 15))
        self.txt_buscar.bind("<KeyRelease>", self._on_key_release)
        self.txt_buscar.bind("<Return>", self._on_enter_busqueda)
        self.txt_buscar.bind("<Down>", lambda e: self._mover_sugerencia(1))
        self.txt_buscar.bind("<Up>", lambda e: self._mover_sugerencia(-1))
        self.txt_buscar.bind("<Escape>", lambda e: self._ocultar_sugerencias())
        self.bind_all("<Button-1>", self._on_click_global, add="+")

        # Lista flotante: cada sugerencia es un botón, así se elige con clic o con el teclado
        self.panel_sugerencias = ctk.CTkFrame(self.area_central, fg_color=Color.SUPERFICIE, border_color=Color.PRIMARIO,
                                              border_width=1, corner_radius=10)
        self.botones_sugerencia = []

        self.tabview = ctk.CTkTabview(self.area_central, fg_color=Color.SUPERFICIE, border_color=Color.BORDE, command=self._on_cambio_tab)
        self.tabview.grid(row=1, column=0, sticky="nsew")

        self.tab_venta = self.tabview.add("Venta")
        self.tab_inventario = self.tabview.add("Inventario")
        if self.tiene_permiso("compras"):
            self.tab_compras = self.tabview.add("Compras")
        if self.tiene_permiso("reportes"):
            self.tab_ganancias = self.tabview.add("Ganancias")
        self.tab_historial = self.tabview.add("Historial")
        self.tab_config = self.tabview.add("Configuración")

        self.grid_productos = ctk.CTkScrollableFrame(self.tab_venta, label_text="Productos Frecuentes",
                                                       fg_color="transparent", label_text_color=Color.TEXTO_SUAVE,
                                                       label_font=ctk.CTkFont(size=16, weight="bold"))
        self.grid_productos.pack(fill="both", expand=True, padx=10, pady=10)
        self.grid_productos.grid_columnconfigure((0, 1, 2), weight=1)

        self._crear_tab_inventario()
        if self.tiene_permiso("compras"):
            self._crear_tab_compras()
        if self.tiene_permiso("reportes"):
            self._crear_tab_ganancias()
        self._crear_tab_historial()
        self._crear_tab_config()

    def _crear_tab_inventario(self):
        panel = ctk.CTkFrame(self.tab_inventario, fg_color="transparent")
        panel.pack(fill="x", padx=10, pady=10)

        self.txt_buscar_inv = ctk.CTkEntry(panel, placeholder_text="Buscar producto...",
                                            height=45, fg_color=Color.FONDO_INPUT, border_color=Color.BORDE, font=ctk.CTkFont(size=14))
        self.txt_buscar_inv.pack(side="left", fill="x", expand=True, padx=(0, 10))
        self.txt_buscar_inv.bind("<KeyRelease>", lambda e: self.cargar_productos_tabla())

        ctk.CTkButton(panel, text="Agregar Producto Nuevo", fg_color=Color.PRIMARIO, hover_color=Color.PRIMARIO_HOVER,
                      font=ctk.CTkFont(size=14, weight="bold"), height=45, width=200,
                      command=self.mostrar_dialogo_producto).pack(side="right")
        if self.tiene_permiso("inventario"):
            ctk.CTkButton(panel, text="Eliminar", fg_color=Color.PELIGRO, hover_color=Color.PELIGRO_HOVER, width=90, height=45,
                          font=ctk.CTkFont(size=14, weight="bold"),
                          command=self.eliminar_producto_seleccionado).pack(side="right", padx=(0, 10))
            ctk.CTkButton(panel, text="Editar", fg_color=Color.GRIS, hover_color=Color.GRIS_HOVER, width=90, height=45,
                          font=ctk.CTkFont(size=14, weight="bold"),
                          command=self.editar_producto_seleccionado).pack(side="right", padx=(0, 10))
        if self.tiene_permiso("compras"):
            ctk.CTkButton(panel, text="Registrar Compra", fg_color=Color.EXITO, hover_color=Color.EXITO_HOVER, width=150, height=45,
                          font=ctk.CTkFont(size=14, weight="bold"),
                          command=self.mostrar_dialogo_compra).pack(side="right", padx=(0, 10))

        if self.tiene_permiso("ver_costos"):
            cols = ("id", "codigo", "barcode", "nombre", "categoria", "unidad", "precio", "costo", "ganancia_u", "stock")
            widths = (40, 70, 130, 220, 110, 70, 80, 80, 100, 80)
        else:
            cols = ("id", "codigo", "barcode", "nombre", "categoria", "unidad", "precio", "stock")
            widths = (40, 80, 140, 260, 120, 80, 90, 90)
        self.tree_productos = TablaBase(self.tab_inventario, cols, widths)
        self.tree_productos.tag_configure("bajo", foreground=Color.AMBAR)
        self.tree_productos.tag_configure("agotado", foreground=Color.PELIGRO_SUAVE)
        self.tree_productos.pack(fill="both", expand=True, padx=10, pady=10)
        if self.tiene_permiso("inventario"):
            self.tree_productos.bind("<Double-1>", lambda e: self.editar_producto_seleccionado())

    def _crear_tab_compras(self):
        panel = ctk.CTkFrame(self.tab_compras, fg_color="transparent")
        panel.pack(fill="x", padx=10, pady=10)
        self.txt_buscar_compra = ctk.CTkEntry(panel, placeholder_text="Buscar por producto o proveedor (ej: arroz)...",
                                              height=45, fg_color=Color.FONDO_INPUT, border_color=Color.BORDE, font=ctk.CTkFont(size=14))
        self.txt_buscar_compra.pack(side="left", fill="x", expand=True, padx=(0, 10))
        self.txt_buscar_compra.bind("<KeyRelease>", lambda e: self.cargar_compras())
        ctk.CTkButton(panel, text="Registrar Compra", fg_color=Color.EXITO, hover_color=Color.EXITO_HOVER,
                      font=ctk.CTkFont(size=14, weight="bold"), height=45, width=180,
                      command=self.mostrar_dialogo_compra).pack(side="right")

        self.lbl_resumen_compras = ctk.CTkLabel(self.tab_compras, text="", font=ctk.CTkFont(size=14, weight="bold"), text_color=Color.TEXTO_SUAVE)
        self.lbl_resumen_compras.pack(side="bottom", anchor="w", padx=15, pady=(0, 10))
        self.tree_compras = TablaBase(self.tab_compras, ("fecha", "producto", "cantidad", "costo_unit", "total", "proveedor", "usuario", "nota"),
                                      (90, 200, 100, 90, 90, 150, 90, 150))
        self.tree_compras.pack(fill="both", expand=True, padx=10, pady=10)

    def _crear_tab_ganancias(self):
        top = ctk.CTkFrame(self.tab_ganancias, fg_color="transparent")
        top.pack(fill="x", padx=10, pady=(10, 0))
        ctk.CTkLabel(top, text="Periodo:", font=ctk.CTkFont(size=14)).pack(side="left", padx=(0, 10))
        self.periodo_var = ctk.StringVar(value="Este mes")
        ctk.CTkOptionMenu(top, variable=self.periodo_var, values=["Hoy", "Últimos 7 días", "Este mes", "Todo"],
                          command=lambda v: self.cargar_ganancias(), font=ctk.CTkFont(size=14)).pack(side="left")

        tarjetas = ctk.CTkFrame(self.tab_ganancias, fg_color="transparent")
        tarjetas.pack(fill="x", padx=10, pady=10)
        tarjetas.grid_columnconfigure((0, 1, 2, 3), weight=1)
        self.lbl_kpi = {}
        for i, (clave, titulo) in enumerate([("ventas", "VENDIDO"), ("costo", "COSTO DE LO VENDIDO"), ("ganancia", "GANANCIA"), ("compras", "COMPRAS (DINERO INVERTIDO)")]):
            card = ModernCard(tarjetas)
            card.grid(row=0, column=i, sticky="nsew", padx=5)
            ctk.CTkLabel(card, text=titulo, font=ctk.CTkFont(size=11, weight="bold"), text_color=Color.TEXTO_SUAVE).pack(pady=(10, 0), padx=10)
            lbl = ctk.CTkLabel(card, text=f"{MONEDA}0.00", font=ctk.CTkFont(size=22, weight="bold"))
            lbl.pack(pady=(0, 10))
            self.lbl_kpi[clave] = lbl

        self.txt_alertas = ctk.CTkTextbox(self.tab_ganancias, height=130, fg_color=Color.FONDO_INPUT, font=ctk.CTkFont(size=13))
        self.txt_alertas.pack(side="bottom", fill="x", padx=10, pady=(0, 10))
        self.tree_ganancias = TablaBase(self.tab_ganancias, ("producto", "vendido", "ingresos", "costo", "ganancia", "margen"),
                                        (220, 110, 100, 100, 100, 80))
        self.tree_ganancias.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    def _crear_tab_historial(self):
        cols = ("id", "numero_boleta", "fecha", "total", "metodo_pago", "vuelto", "usuario")
        if self.tiene_permiso("reportes"):
            cols += ("ganancia",)
        self.tree_ventas = TablaBase(self.tab_historial, cols)
        self.tree_ventas.pack(fill="both", expand=True, padx=10, pady=10)

    def _crear_tab_config(self):
        config = ConfigRepository.obtener()
        licencia_ok, licencia_msg = LicenciaRepository.verificar()

        frame_scroll = ctk.CTkScrollableFrame(self.tab_config, fg_color="transparent")
        frame_scroll.pack(fill="both", expand=True, padx=20, pady=20)

        frame_negocio = ctk.CTkFrame(frame_scroll, fg_color=Color.SUPERFICIE)
        frame_negocio.pack(fill="x", pady=(0, 15))
        ctk.CTkLabel(frame_negocio, text="Datos del Negocio", font=ctk.CTkFont(size=16, weight="bold")).pack(anchor="w", padx=15, pady=10)

        self.config_vars = {}
        for clave, label, valor in [("nombre", "Nombre:", config.get("nombre", "")), ("rut", "RUT/NIF:", config.get("rut", "")), ("direccion", "Dirección:", config.get("direccion", "")), ("telefono", "Teléfono:", config.get("telefono", ""))]:
            ctk.CTkLabel(frame_negocio, text=label, font=ctk.CTkFont(size=12)).pack(anchor="w", padx=15, pady=(5, 2))
            var = ctk.StringVar(value=valor)
            self.config_vars[clave] = var
            ctk.CTkEntry(frame_negocio, textvariable=var, width=350, fg_color=Color.FONDO_INPUT, border_color=Color.BORDE, font=ctk.CTkFont(size=14), height=35).pack(fill="x", padx=15, pady=(0, 5))

        ctk.CTkButton(frame_negocio, text="Guardar Datos", fg_color=Color.PRIMARIO, hover_color=Color.PRIMARIO_HOVER,
                      font=ctk.CTkFont(size=14, weight="bold"), height=40, command=self.guardar_config).pack(anchor="w", padx=15, pady=15)

        if self.tiene_permiso("todo"):
            frame_licencia = ctk.CTkFrame(frame_scroll, fg_color=Color.SUPERFICIE)
            frame_licencia.pack(fill="x", pady=(0, 15))
            ctk.CTkLabel(frame_licencia, text="Licencia del Sistema", font=ctk.CTkFont(size=16, weight="bold")).pack(anchor="w", padx=15, pady=10)
            ctk.CTkLabel(frame_licencia, text=f"Estado: {licencia_msg}", font=ctk.CTkFont(size=14),
                         text_color=Color.EXITO if licencia_ok else Color.PELIGRO).pack(anchor="w", padx=15, pady=5)
            frame_meses = ctk.CTkFrame(frame_licencia, fg_color="transparent")
            frame_meses.pack(fill="x", padx=15, pady=10)
            for meses, texto in [(6, "6 Meses"), (12, "1 Año")]:
                ctk.CTkButton(frame_meses, text=texto, font=ctk.CTkFont(size=14, weight="bold"), height=40,
                              fg_color=Color.EXITO, hover_color=Color.EXITO_HOVER,
                              command=lambda m=meses: self.activar_licencia(m)).pack(side="left", padx=5)

        frame_usuarios = ctk.CTkFrame(frame_scroll, fg_color=Color.SUPERFICIE)
        frame_usuarios.pack(fill="x", pady=(0, 15))
        ctk.CTkLabel(frame_usuarios, text="Gestión de Usuarios", font=ctk.CTkFont(size=16, weight="bold")).pack(anchor="w", padx=15, pady=10)

        for u in UsuarioRepository.obtener_todos():
            frame_user = ctk.CTkFrame(frame_usuarios, fg_color="transparent")
            frame_user.pack(fill="x", padx=15, pady=3)
            ctk.CTkLabel(frame_user, text=f"{u[0]} ({ROLES.get(u[1], {}).get('nombre', u[1])})",
                         font=ctk.CTkFont(size=14)).pack(side="left")
            if self.tiene_permiso("todo") and u[0] != self.usuario_actual["usuario"]:
                ctk.CTkButton(frame_user, text="Eliminar", width=80, height=28, fg_color=Color.PELIGRO, hover_color=Color.PELIGRO_HOVER,
                              font=ctk.CTkFont(size=11), command=lambda user=u[0]: self.eliminar_usuario_app(user)).pack(side="right")

        if self.tiene_permiso("todo"):
            ctk.CTkButton(frame_usuarios, text="+ Agregar Usuario", fg_color=Color.PRIMARIO, hover_color=Color.PRIMARIO_HOVER,
                          font=ctk.CTkFont(size=14, weight="bold"), height=35,
                          command=self.mostrar_dialogo_usuario).pack(anchor="w", padx=15, pady=10)

            frame_clave = ctk.CTkFrame(frame_scroll, fg_color=Color.SUPERFICIE)
            frame_clave.pack(fill="x", pady=(0, 15))
            ctk.CTkLabel(frame_clave, text="Cambiar Contraseña", font=ctk.CTkFont(size=16, weight="bold")).pack(anchor="w", padx=15, pady=10)

            ctk.CTkLabel(frame_clave, text="Usuario:", font=ctk.CTkFont(size=12)).pack(anchor="w", padx=15, pady=(5, 2))
            self.cambiar_user_var = ctk.StringVar()
            ctk.CTkOptionMenu(frame_clave, variable=self.cambiar_user_var,
                              values=[u[0] for u in UsuarioRepository.obtener_todos()],
                              font=ctk.CTkFont(size=14)).pack(fill="x", padx=15, pady=(0, 10))

            ctk.CTkLabel(frame_clave, text="Nueva contraseña:", font=ctk.CTkFont(size=12)).pack(anchor="w", padx=15, pady=(5, 2))
            self.cambiar_clave_var = ctk.StringVar()
            ctk.CTkEntry(frame_clave, textvariable=self.cambiar_clave_var, show="*",
                         font=ctk.CTkFont(size=14), height=35).pack(fill="x", padx=15, pady=(0, 10))

            ctk.CTkButton(frame_clave, text="Actualizar Contraseña", fg_color=Color.EXITO, hover_color=Color.EXITO_HOVER,
                          font=ctk.CTkFont(size=14, weight="bold"), height=40,
                          command=self.cambiar_contrasena).pack(anchor="w", padx=15, pady=10)

    def _crear_panel_carrito(self):
        self.panel_carrito = ctk.CTkFrame(self, corner_radius=12, fg_color=Color.SUPERFICIE)
        self.panel_carrito.grid(row=0, column=2, sticky="nsew", padx=(0, 20), pady=20)
        self.panel_carrito.grid_rowconfigure(1, weight=1)

        ctk.CTkLabel(self.panel_carrito, text="Resumen de Venta", font=ctk.CTkFont(size=16, weight="bold")).pack(padx=20, pady=15, anchor="w")
        self.lista_articulos = ctk.CTkScrollableFrame(self.panel_carrito, fg_color="transparent")
        self.lista_articulos.pack(fill="both", expand=True, padx=10, pady=5)

        ctk.CTkFrame(self.panel_carrito, height=2, fg_color=Color.BORDE).pack(fill="x", padx=20, pady=10)

        self.lbl_total = ctk.CTkLabel(self.panel_carrito, text=f"TOTAL: {MONEDA}0.00",
                                      font=ctk.CTkFont(size=24, weight="bold"), text_color=Color.EXITO)
        self.lbl_total.pack(padx=20, pady=5, anchor="e")

        ctk.CTkLabel(self.panel_carrito, text="Método de Pago:", font=ctk.CTkFont(size=11)).pack(padx=20, pady=(10, 2), anchor="w")

        self.pago_var = ctk.StringVar(value="Efectivo")
        pago_frame = ctk.CTkFrame(self.panel_carrito, fg_color="transparent")
        pago_frame.pack(fill="x", padx=20, pady=5)
        for metodo in ["Efectivo", "Yape", "Transferencia", "Tarjeta"]:
            ctk.CTkRadioButton(pago_frame, text=metodo, variable=self.pago_var, value=metodo,
                               font=ctk.CTkFont(size=14), command=lambda m=metodo: self.seleccionar_pago(m)).pack(side="left", padx=5)

        ctk.CTkButton(self.panel_carrito, text="COBRAR (F5)", fg_color=Color.COBRAR, hover_color=Color.COBRAR_HOVER,
                      height=55, font=ctk.CTkFont(size=18, weight="bold"), command=self.cobrar_venta).pack(fill="x", padx=20, pady=(15, 10))
        ctk.CTkButton(self.panel_carrito, text="Cancelar", fg_color=Color.PELIGRO, hover_color=Color.PELIGRO_HOVER,
                      font=ctk.CTkFont(size=14), height=40, command=self.limpiar_venta).pack(fill="x", padx=20, pady=(0, 20))

    # ============================================================
    # AUTOCOMPLETADO
    # ============================================================

    def _on_key_release(self, event):
        if event.keysym in ("Down", "Up", "Return", "Escape", "Left", "Right", "Tab"):
            return
        self._actualizar_sugerencias()

    def _actualizar_sugerencias(self):
        texto = self.txt_buscar.get().strip()
        if not texto:
            self._ocultar_sugerencias()
            return
        self.sugerencias = ProductoRepository.obtener_todos(texto)[:8]
        self.sugerencia_seleccionada = -1
        for boton in self.botones_sugerencia:
            boton.destroy()
        self.botones_sugerencia = []
        if not self.sugerencias:
            self._ocultar_sugerencias()
            return
        for p in self.sugerencias:
            stock = "AGOTADO" if p.stock <= 0 else f"Stock: {p.stock:g} {p.unidad}"
            boton = ctk.CTkButton(self.panel_sugerencias, anchor="w", height=38, corner_radius=6,
                                  text=f"{p.nombre}     {p.codigo}     {MONEDA}{p.precio:.2f}     {stock}",
                                  fg_color="transparent", hover_color=Color.BORDE, font=ctk.CTkFont(size=13),
                                  text_color=Color.PELIGRO_SUAVE if p.stock <= 0 else Color.TEXTO,
                                  command=lambda prod=p: self._elegir_sugerencia(prod))
            boton.pack(fill="x", padx=4, pady=2)
            self.botones_sugerencia.append(boton)
        self.panel_sugerencias.place(relx=0, y=54, relwidth=1)
        self.panel_sugerencias.lift()

    def _ocultar_sugerencias(self):
        self.panel_sugerencias.place_forget()
        self.sugerencia_seleccionada = -1

    def _mover_sugerencia(self, paso):
        if self.sugerencias and self.panel_sugerencias.winfo_ismapped():
            self.sugerencia_seleccionada = (self.sugerencia_seleccionada + paso) % len(self.sugerencias)
            for i, boton in enumerate(self.botones_sugerencia):
                boton.configure(fg_color=Color.PRIMARIO if i == self.sugerencia_seleccionada else "transparent")
        return "break"

    def _on_enter_busqueda(self, event=None):
        texto = self.txt_buscar.get().strip()
        if not texto:
            return
        if self.sugerencia_seleccionada >= 0:
            self._elegir_sugerencia(self.sugerencias[self.sugerencia_seleccionada])
            return
        exacto = ProductoRepository.obtener_por_codigo(texto)      # lector de código de barras
        if exacto:
            self._elegir_sugerencia(exacto)
        elif self.sugerencias:
            self._elegir_sugerencia(self.sugerencias[0])
        else:
            self.bell()

    def _elegir_sugerencia(self, producto):
        """Agrega el producto a la venta y deja el buscador listo para el siguiente."""
        self._ocultar_sugerencias()
        self.txt_buscar.delete(0, "end")
        self.agregar_a_venta(producto)
        self.txt_buscar.focus_set()

    def _on_click_global(self, event):
        """Cierra la lista de sugerencias al hacer clic fuera de ella."""
        if not self.panel_sugerencias.winfo_ismapped():
            return
        destino = str(event.widget)
        if not destino.startswith(str(self.panel_sugerencias)) and not destino.startswith(str(self.txt_buscar)):
            self._ocultar_sugerencias()

    # ============================================================
    # NAVEGACIÓN
    # ============================================================

    def _entradas_menu(self):
        entradas = [("venta", "Nueva Venta"), ("inventario", "Inventario")]
        if self.tiene_permiso("compras"):
            entradas.append(("compras", "Compras"))
        if self.tiene_permiso("reportes"):
            entradas.append(("ganancias", "Ganancias"))
        entradas += [("historial", "Historial"), ("config", "Configuración")]
        return entradas

    def _on_cambio_tab(self):
        tab = self.tabview.get()
        if tab == "Venta":
            self.cargar_productos_venta()
        elif tab == "Inventario":
            self.cargar_productos_tabla()
        elif tab == "Compras":
            self.cargar_compras()
        elif tab == "Ganancias":
            self.cargar_ganancias()
        elif tab == "Historial":
            self.cargar_ventas()

    def _refrescar_todo(self):
        self.cargar_productos_venta()
        self.cargar_productos_tabla()
        if hasattr(self, "tree_compras"):
            self.cargar_compras()
        if hasattr(self, "tree_ganancias"):
            self.cargar_ganancias()

    def cambiar_pagina(self, pagina):
        for clave, btn in self.botones_menu.items():
            if clave == pagina:
                btn.configure(fg_color=Color.PRIMARIO, text_color="white")
            else:
                btn.configure(fg_color="transparent", text_color=Color.TEXTO_SUAVE)
        if pagina == "venta":
            self.tabview.set("Venta")
            self.cargar_productos_venta()
        elif pagina == "inventario":
            if self.tiene_permiso("inventario") or self.tiene_permiso("agregar_producto"):
                self.tabview.set("Inventario")
                self.cargar_productos_tabla()
            else:
                messagebox.showwarning("Sin permiso", "No tienes permiso para ver el inventario.")
        elif pagina == "compras":
            if self.tiene_permiso("compras"):
                self.tabview.set("Compras")
                self.cargar_compras()
            else:
                messagebox.showwarning("Sin permiso", "Solo el administrador o la dueña pueden ver las compras.")
        elif pagina == "ganancias":
            if self.tiene_permiso("reportes"):
                self.tabview.set("Ganancias")
                self.cargar_ganancias()
            else:
                messagebox.showwarning("Sin permiso", "Solo el administrador o la dueña pueden ver las ganancias.")
        elif pagina == "historial":
            self.tabview.set("Historial")
            self.cargar_ventas()
        elif pagina == "config":
            self.tabview.set("Configuración")

    # ============================================================
    # VENTA
    # ============================================================

    def cargar_productos_venta(self):
        for widget in self.grid_productos.winfo_children():
            widget.destroy()
        filtro = self.txt_buscar.get().strip()
        productos = ProductoRepository.obtener_todos(filtro)
        for i, p in enumerate(productos):
            sin_stock = p.stock <= 0
            stock_bajo = p.stock > 0 and p.stock <= (p.stock_minimo if p.stock_minimo is not None else 5)
            color_fg = (Color.ROJO_CLARO, Color.SUPERFICIE) if sin_stock else (("white", "gray15") if not stock_bajo else (Color.AMBAR_CLARO, Color.AMBAR_OSCURO))
            color_hover = (Color.ROJO_CLARO_HOVER, Color.BORDE) if sin_stock else (("gray90", "gray25") if not stock_bajo else (Color.AMBAR_CLARO_HOVER, Color.AMBAR_OSCURO_HOVER))
            texto = f"{p.nombre}\n{MONEDA}{p.precio:.2f}" + ("" if p.unidad == "unidad" else f" / {p.unidad}")
            if stock_bajo:
                texto += f"\nQuedan {p.stock:g}"
            btn = ctk.CTkButton(self.grid_productos, text=texto, fg_color=color_fg, text_color=("black", "white"),
                                hover_color=color_hover, height=100, corner_radius=10,
                                font=ctk.CTkFont(size=14, weight="bold"), command=lambda p=p: self.agregar_a_venta(p))
            btn.grid(row=i // 3, column=i % 3, padx=10, pady=10, sticky="nsew")

    def agregar_a_venta(self, p):
        if p.stock <= 0:
            messagebox.showwarning("Sin stock", f"No hay stock de {p.nombre}")
            return
        cantidad = 1
        if p.unidad != "unidad":
            cantidad = pedir_numero("Cantidad", f"{p.nombre}: ¿cuántos {p.unidad}?", parent=self, minimo=0.001)
            if not cantidad:
                return
        for item in self.items_venta:
            if item["producto_id"] == p.id:
                if item["cantidad"] + cantidad > p.stock + 1e-9:
                    messagebox.showwarning("Sin stock", f"No hay suficiente stock (quedan {p.stock:g} {p.unidad}).")
                    return
                item["cantidad"] = round(item["cantidad"] + cantidad, 3)
                item["subtotal"] = round(item["cantidad"] * item["precio_unitario"], 2)
                self.actualizar_carrito()
                return
        if cantidad > p.stock + 1e-9:
            messagebox.showwarning("Sin stock", f"No hay suficiente stock (quedan {p.stock:g} {p.unidad}).")
            return
        self.items_venta.append({"producto_id": p.id, "codigo": p.codigo, "nombre": p.nombre, "unidad": p.unidad, "cantidad": cantidad,
                                 "precio_unitario": p.precio, "subtotal": round(cantidad * p.precio, 2)})
        self.actualizar_carrito()

    def actualizar_carrito(self):
        for widget in self.lista_articulos.winfo_children():
            widget.destroy()
        total = 0
        for i, item in enumerate(self.items_venta):
            frame_item = ctk.CTkFrame(self.lista_articulos, fg_color="transparent")
            frame_item.pack(fill="x", pady=3)
            ctk.CTkLabel(frame_item, text=(f"{item['cantidad']:g}x {item['nombre']}" if item.get("unidad", "unidad") == "unidad" else f"{item['cantidad']:g} {item['unidad']} {item['nombre']}"), font=ctk.CTkFont(size=14)).pack(side="left")
            ctk.CTkLabel(frame_item, text=f"{MONEDA}{item['subtotal']:.2f}", font=ctk.CTkFont(size=14)).pack(side="right")
            ctk.CTkButton(frame_item, text="X", width=30, height=30, fg_color=Color.PELIGRO, hover_color=Color.PELIGRO_HOVER,
                          font=ctk.CTkFont(size=12), command=lambda idx=i: self.quitar_item(idx)).pack(side="right", padx=5)
            total += item["subtotal"]
        self.lbl_total.configure(text=f"TOTAL: {MONEDA}{total:,.2f}")

    def quitar_item(self, idx):
        self.items_venta.pop(idx)
        self.actualizar_carrito()

    def limpiar_venta(self):
        if not self.items_venta:
            return
        if messagebox.askyesno("Confirmar", "¿Cancelar la venta actual?"):
            self.items_venta = []
            self.actualizar_carrito()

    def seleccionar_pago(self, metodo):
        self.metodo_pago = metodo

    def cobrar_venta(self):
        if not self.items_venta:
            messagebox.showwarning("Vacío", "Agrega productos primero.")
            return
        total = sum(item["subtotal"] for item in self.items_venta)
        vuelto = 0
        if self.metodo_pago == "Efectivo":
            efectivo = pedir_numero("Efectivo", f"Total: {MONEDA}{total:,.2f}\n¿Con cuánto paga?", parent=self, minimo=0)
            if efectivo is None:
                return
            if efectivo < total:
                messagebox.showerror("Error", "El monto es menor al total.")
                return
            vuelto = efectivo - total
        if not messagebox.askyesno("Confirmar", f"Total: {MONEDA}{total:,.2f}\nPago: {self.metodo_pago}\n¿Confirmar?"):
            return
        numero_boleta, total = VentaRepository.registrar(self.items_venta, self.metodo_pago, vuelto, self.usuario_actual["usuario"])
        if numero_boleta:
            BoletaDialog(self, numero_boleta, total, vuelto, self.items_venta, self.usuario_actual["nombre"])
            self.items_venta = []
            self.actualizar_carrito()
            self.cargar_productos_venta()
        else:
            messagebox.showerror("Error", f"No se pudo registrar: {total}")

    # ============================================================
    # INVENTARIO
    # ============================================================

    def cargar_productos_tabla(self):
        for item in self.tree_productos.get_children():
            self.tree_productos.delete(item)
        filtro = self.txt_buscar_inv.get().strip()
        ver_costos = self.tiene_permiso("ver_costos")
        for p in ProductoRepository.obtener_todos(filtro):
            # Antes se pasaba `values=p` (un sqlite3.Row) y Tkinter lo mostraba como texto.
            # Ahora armamos una lista con cada valor ya formateado.
            valores = [p.id, p.codigo, p.barcode, p.nombre, p.categoria, p.unidad, f"{MONEDA}{p.precio:.2f}"]
            if ver_costos:
                costo = p.costo or 0
                valores.append(f"{MONEDA}{costo:.2f}")
                valores.append(f"{MONEDA}{p.precio - costo:.2f}" if costo > 0 else "sin costo")
            valores.append(f"{p.stock:g}")
            tag = ("agotado",) if p.stock <= 0 else (("bajo",) if p.stock <= (p.stock_minimo if p.stock_minimo is not None else 5) else ())
            self.tree_productos.insert("", "end", values=valores, tags=tag)

    def _producto_seleccionado(self):
        sel = self.tree_productos.selection()
        if not sel:
            messagebox.showinfo("Selecciona un producto", "Haz clic en un producto de la tabla primero.")
            return None
        return ProductoRepository.obtener_por_id(int(self.tree_productos.item(sel[0])["values"][0]))

    def mostrar_dialogo_producto(self):
        ProductoDialog(self, on_guardar=self._refrescar_todo, ver_costos=self.tiene_permiso("ver_costos"),
                       usuario=self.usuario_actual["usuario"])

    def editar_producto_seleccionado(self):
        p = self._producto_seleccionado()
        if p:
            ProductoDialog(self, producto=p, on_guardar=self._refrescar_todo, ver_costos=self.tiene_permiso("ver_costos"),
                           usuario=self.usuario_actual["usuario"])

    def eliminar_producto_seleccionado(self):
        if not self.tiene_permiso("eliminar_producto"):
            messagebox.showwarning("Sin permiso", "No tienes permiso para eliminar productos.")
            return
        p = self._producto_seleccionado()
        if p and messagebox.askyesno("Confirmar", f"¿Eliminar '{p.nombre}'?"):
            ok, msg = ProductoRepository.eliminar(p.id)
            if ok:
                self._refrescar_todo()
            else:
                messagebox.showwarning("No se puede eliminar", msg)

    # ============================================================
    # COMPRAS
    # ============================================================

    def mostrar_dialogo_compra(self):
        if not self.tiene_permiso("compras"):
            messagebox.showwarning("Sin permiso", "Solo el administrador o la dueña pueden registrar compras.")
            return
        sel = self.tree_productos.selection() if hasattr(self, "tree_productos") else ()
        pid = int(self.tree_productos.item(sel[0])["values"][0]) if sel else None
        CompraDialog(self, self.usuario_actual["usuario"], on_guardar=self._refrescar_todo, producto_id=pid)

    def cargar_compras(self):
        for item in self.tree_compras.get_children():
            self.tree_compras.delete(item)
        filas = CompraRepository.obtener(self.txt_buscar_compra.get().strip())
        total_gastado = 0
        for f in filas:
            total_gastado += f[6]
            self.tree_compras.insert("", "end", values=(f[1], f[2], f"{f[4]:g} {f[3]}", f"{MONEDA}{f[5]:.2f}", f"{MONEDA}{f[6]:,.2f}", f[7] or "-", f[8] or "-", f[9] or ""))
        texto = f"{len(filas)} compra(s)  |  Total gastado: {MONEDA}{total_gastado:,.2f}"
        if filas and len({f[2] for f in filas}) == 1:
            cant = sum(f[4] for f in filas)
            if cant > 0:
                texto += f"  |  Total comprado: {cant:g} {filas[0][3]}  |  Costo promedio: {MONEDA}{total_gastado / cant:.2f} por {filas[0][3]}"
        self.lbl_resumen_compras.configure(text=texto)

    # ============================================================
    # GANANCIAS
    # ============================================================

    def _rango_periodo(self):
        hoy = datetime.now().date()
        p = self.periodo_var.get()
        if p == "Hoy":
            desde = hoy
        elif p == "Últimos 7 días":
            desde = hoy - timedelta(days=6)
        elif p == "Este mes":
            desde = hoy.replace(day=1)
        else:
            return "0000-01-01", hoy.isoformat()
        return desde.isoformat(), hoy.isoformat()

    def cargar_ganancias(self):
        desde, hasta = self._rango_periodo()
        for item in self.tree_ganancias.get_children():
            self.tree_ganancias.delete(item)
        filas = ReporteRepository.ganancias(desde, hasta)
        ingresos = sum(f[3] or 0 for f in filas)
        costo = sum(f[4] or 0 for f in filas)
        ganancia = ingresos - costo
        for f in filas:
            margen = (f[5] / f[3] * 100) if f[3] else 0
            self.tree_ganancias.insert("", "end", values=(f[0], f"{f[2]:g} {f[1]}", f"{MONEDA}{f[3]:,.2f}", f"{MONEDA}{f[4]:,.2f}", f"{MONEDA}{f[5]:,.2f}", f"{margen:.0f}%"))
        self.lbl_kpi["ventas"].configure(text=f"{MONEDA}{ingresos:,.2f}")
        self.lbl_kpi["costo"].configure(text=f"{MONEDA}{costo:,.2f}")
        self.lbl_kpi["ganancia"].configure(text=f"{MONEDA}{ganancia:,.2f}", text_color=Color.EXITO if ganancia >= 0 else Color.PELIGRO)
        self.lbl_kpi["compras"].configure(text=f"{MONEDA}{ReporteRepository.total_compras(desde, hasta):,.2f}")

        a = ReporteRepository.alertas()
        lineas = []
        if a["bajo"]:
            lineas.append("STOCK BAJO / AGOTADO:")
            lineas += [f"  • {n}: quedan {s:g} {u} (mínimo {m:g})" for n, s, u, m in a["bajo"]]
        if a["sin_costo"]:
            lineas.append("SIN COSTO REGISTRADO (su ganancia sale inflada hasta que registres una compra):")
            lineas.append("  • " + ", ".join(a["sin_costo"]))
        if a["sin_ganancia"]:
            lineas.append("PRECIO MENOR O IGUAL AL COSTO (no ganas o pierdes):")
            lineas += [f"  • {n}: vendes a {MONEDA}{pr:.2f}, te cuesta {MONEDA}{co:.2f}" for n, pr, co in a["sin_ganancia"]]
        self.txt_alertas.configure(state="normal")
        self.txt_alertas.delete("1.0", "end")
        self.txt_alertas.insert("1.0", "\n".join(lineas) if lineas else "Sin alertas. Todo en orden.")
        self.txt_alertas.configure(state="disabled")

    # ============================================================
    # HISTORIAL
    # ============================================================

    def cargar_ventas(self):
        for item in self.tree_ventas.get_children():
            self.tree_ventas.delete(item)
        ver_ganancia = self.tiene_permiso("reportes")
        for v in VentaRepository.obtener_todas():
            valores = [v[0], v[1], v[2], f"{MONEDA}{v[3]:,.2f}", v[4], f"{MONEDA}{v[5]:,.2f}" if v[5] else "-", v[6] or "-"]
            if ver_ganancia:
                valores.append(f"{MONEDA}{v[7]:,.2f}")
            self.tree_ventas.insert("", "end", values=valores)

    # ============================================================
    # CONFIGURACIÓN
    # ============================================================

    def guardar_config(self):
        for clave, var in self.config_vars.items():
            ConfigRepository.guardar(clave, var.get())
        messagebox.showinfo("Éxito", "Configuración guardada.")

    def activar_licencia(self, meses):
        fecha = LicenciaRepository.activar(meses)
        messagebox.showinfo("Licencia activada", f"Licencia activada por {meses} meses.\nVence: {fecha.strftime('%d/%m/%Y')}")
        self.cambiar_pagina("config")

    def eliminar_usuario_app(self, usuario):
        if messagebox.askyesno("Confirmar", f"¿Eliminar el usuario '{usuario}'?"):
            UsuarioRepository.eliminar(usuario)
            self.cambiar_pagina("config")

    def mostrar_dialogo_usuario(self):
        UsuarioDialog(self, on_guardar=lambda: self.cambiar_pagina("config"))

    def cambiar_contrasena(self):
        usuario = self.cambiar_user_var.get()
        nueva_clave = self.cambiar_clave_var.get()
        if not usuario or not nueva_clave:
            messagebox.showwarning("Atención", "Selecciona usuario y escribe la nueva contraseña.")
            return
        ok, msg = UsuarioRepository.cambiar_clave(usuario, nueva_clave)
        if ok:
            messagebox.showinfo("Éxito", msg)
            self.cambiar_clave_var.set("")
        else:
            messagebox.showerror("Error", msg)

    # ============================================================
    # PERMISOS
    # ============================================================

    def tiene_permiso(self, permiso):
        if not self.usuario_actual:
            return False
        rol = self.usuario_actual["rol"]
        if rol == "admin":
            return True
        return permiso in ROLES[rol]["permisos"]


def configurar_identidad_windows():
    """Hace que la barra de tareas muestre el logo de la tienda y no el de Python."""
    if sys.platform.startswith("win"):
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
        except Exception:
            pass


def main():
    configurar_identidad_windows()
    app = TiendaRapidaApp()
    app.mainloop()
