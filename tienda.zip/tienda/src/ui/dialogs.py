"""Ventanas de diálogo: login, producto, compra, usuario y boleta."""
from datetime import datetime
from tkinter import messagebox

import customtkinter as ctk

from src.config import MONEDA, STOCK_MINIMO_DEFECTO, UNIDADES, Color
from src.repositories import CompraRepository, ConfigRepository, ProductoRepository, UsuarioRepository
from src.ui.components import DialogoBase, crear_campo
from src.utils import numero_a_texto, parse_decimal


class LoginDialog(DialogoBase):
    def __init__(self, parent, on_success):
        super().__init__("Iniciar Sesión", 400, 500)
        self.on_success = on_success
        self._crear_contenido()
        self.bind("<Return>", lambda e: self._login())

    def _crear_contenido(self):
        frame = ctk.CTkFrame(self, fg_color="transparent")
        frame.pack(fill="both", expand=True, padx=30, pady=30)

        # Título
        ctk.CTkLabel(frame, text="TiendaPro", font=ctk.CTkFont(size=24, weight="bold"),
                     text_color=Color.PRIMARIO).pack(pady=(0, 30))

        # Campo Usuario
        ctk.CTkLabel(frame, text="Usuario:", font=ctk.CTkFont(size=14)).pack(anchor="w")
        self.usuario_var = ctk.StringVar()
        ctk.CTkEntry(frame, textvariable=self.usuario_var, font=ctk.CTkFont(size=14),
                     height=40).pack(fill="x", pady=(0, 15))

        # Campo Contraseña
        ctk.CTkLabel(frame, text="Contraseña:", font=ctk.CTkFont(size=14)).pack(anchor="w")
        self.clave_var = ctk.StringVar()
        ctk.CTkEntry(frame, textvariable=self.clave_var, show="*", font=ctk.CTkFont(size=14),
                     height=40).pack(fill="x", pady=(0, 20))

        # Botón Ingresar
        ctk.CTkButton(frame, text="Ingresar", font=ctk.CTkFont(size=16, weight="bold"),
                      height=45, fg_color=Color.PRIMARIO, hover_color=Color.PRIMARIO_HOVER,
                      command=self._login).pack(fill="x", pady=20)

        # Usuarios por defecto
        ctk.CTkLabel(frame, text="Usuarios por defecto:",
                     font=ctk.CTkFont(size=11), text_color="gray").pack(anchor="w", pady=(10, 0))
        ctk.CTkLabel(frame, text="admin / admin123  •  duena / duena123  •  trabajador / trabaja123",
                     font=ctk.CTkFont(size=10), text_color="gray", justify="center").pack(pady=5)

    def _login(self):
        usuario = self.usuario_var.get().strip()
        clave = self.clave_var.get().strip()

        if not usuario or not clave:
            messagebox.showwarning("Atención", "Usuario y contraseña son obligatorios.")
            return

        resultado = UsuarioRepository.login(usuario, clave)
        if resultado:
            self.destroy()
            self.on_success(resultado)
        else:
            messagebox.showerror("Error", "Usuario o contraseña incorrectos.", parent=self)


class ProductoDialog(DialogoBase):
    def __init__(self, parent, producto=None, on_guardar=None, ver_costos=False, usuario=""):
        super().__init__("Agregar Producto" if producto is None else "Editar Producto", 500, 720)
        self.producto = producto
        self.on_guardar = on_guardar
        self.ver_costos = ver_costos
        self.usuario = usuario
        self._crear_contenido()

    def _crear_contenido(self):
        p = self.producto
        ctk.CTkButton(self, text="Guardar", command=self._guardar, fg_color=Color.PRIMARIO, hover_color=Color.PRIMARIO_HOVER,
                      font=ctk.CTkFont(size=16, weight="bold"), height=45).pack(side="bottom", fill="x", padx=20, pady=15)
        frame = ctk.CTkScrollableFrame(self, fg_color="transparent")
        frame.pack(fill="both", expand=True, padx=20, pady=(20, 0))

        self.codigo_var = ctk.StringVar(value=p.codigo if p else ProductoRepository.generar_codigo_automatico())
        self.barcode_var = ctk.StringVar(value=p.barcode if p else ProductoRepository.generar_barcode())
        self.nombre_var = ctk.StringVar(value=p.nombre if p else "")
        self.categoria_var = ctk.StringVar(value=p.categoria if p else "General")
        self.unidad_var = ctk.StringVar(value=(p.unidad or "unidad") if p else "unidad")
        self.precio_var = ctk.StringVar(value=numero_a_texto(p.precio) if p else "")
        self.costo_var = ctk.StringVar(value=numero_a_texto(p.costo) if p else "")
        self.stock_var = ctk.StringVar(value=numero_a_texto(p.stock) if p else "")
        self.minimo_var = ctk.StringVar(value=numero_a_texto(p.stock_minimo if p.stock_minimo is not None else STOCK_MINIMO_DEFECTO) if p else str(STOCK_MINIMO_DEFECTO))

        crear_campo(frame, "Código:", self.codigo_var)
        crear_campo(frame, "Código de Barras:", self.barcode_var)
        crear_campo(frame, "Nombre:", self.nombre_var)
        crear_campo(frame, "Categoría:", self.categoria_var)

        ctk.CTkLabel(frame, text="Se vende por:", font=ctk.CTkFont(size=14)).pack(anchor="w")
        ctk.CTkOptionMenu(frame, variable=self.unidad_var, values=UNIDADES, font=ctk.CTkFont(size=14),
                          command=lambda v: self._actualizar_ganancia()).pack(fill="x", pady=(0, 10))

        crear_campo(frame, f"Precio de venta ({MONEDA}):", self.precio_var, numerico=True)
        if self.ver_costos:
            crear_campo(frame, f"Costo de compra ({MONEDA} por unidad/kg):", self.costo_var, numerico=True)
            self.lbl_ganancia = ctk.CTkLabel(frame, text="", font=ctk.CTkFont(size=14, weight="bold"))
            self.lbl_ganancia.pack(anchor="w", pady=(0, 10))
            self.precio_var.trace_add("write", self._actualizar_ganancia)
            self.costo_var.trace_add("write", self._actualizar_ganancia)
            self._actualizar_ganancia()
        crear_campo(frame, "Stock:", self.stock_var, numerico=True)
        crear_campo(frame, "Avisar cuando el stock sea menor o igual a:", self.minimo_var, numerico=True)

    def _actualizar_ganancia(self, *args):
        try:
            precio = parse_decimal(self.precio_var.get())
            costo = parse_decimal(self.costo_var.get())
        except ValueError:
            self.lbl_ganancia.configure(text="")
            return
        ganancia = precio - costo
        margen = ganancia / precio * 100 if precio > 0 else 0
        self.lbl_ganancia.configure(text=f"Ganancia por {self.unidad_var.get()}: {MONEDA}{ganancia:.2f}  (margen {margen:.0f}%)",
                                    text_color=Color.EXITO if ganancia > 0 else Color.PELIGRO)

    def _guardar(self):
        try:
            codigo = self.codigo_var.get().strip()
            barcode = self.barcode_var.get().strip()
            nombre = self.nombre_var.get().strip()
            categoria = self.categoria_var.get().strip() or "General"
            unidad = self.unidad_var.get()
            precio = parse_decimal(self.precio_var.get())
            costo = parse_decimal(self.costo_var.get(), vacio=0.0) if self.ver_costos else (self.producto.costo or 0 if self.producto else 0.0)
            stock = parse_decimal(self.stock_var.get(), vacio=0.0)
            minimo = parse_decimal(self.minimo_var.get(), vacio=float(STOCK_MINIMO_DEFECTO))
        except ValueError:
            messagebox.showerror("Error", "Precio, costo, stock y mínimo deben ser números.", parent=self)
            return

        if not codigo or not nombre:
            messagebox.showwarning("Atención", "Código y nombre son obligatorios.", parent=self)
            return
        if precio < 0 or costo < 0 or stock < 0 or minimo < 0:
            messagebox.showwarning("Atención", "Los valores no pueden ser negativos.", parent=self)
            return

        if self.producto:
            ok, msg = ProductoRepository.actualizar(self.producto.id, codigo, barcode, nombre, categoria, precio, stock, unidad, costo, minimo)
        else:
            productos = ProductoRepository.obtener_todos()
            while any(p.codigo == codigo for p in productos):
                numero = int(codigo[1:]) + 1 if codigo.startswith("P") and codigo[1:].isdigit() else len(productos) + 1
                codigo = f"P{numero:03d}"
            ok, msg = ProductoRepository.agregar(codigo, barcode, nombre, categoria, precio, stock, unidad, costo, minimo, self.usuario)

        if ok:
            messagebox.showinfo("Éxito", msg, parent=self)
            self.destroy()
            if self.on_guardar:
                self.on_guardar()
        else:
            messagebox.showerror("Error", msg, parent=self)


class CompraDialog(DialogoBase):
    """Registrar una compra de mercadería (reposición). Ej.: 1 de setiembre compré arroz, el 15 otra vez."""
    def __init__(self, parent, usuario, on_guardar=None, producto_id=None):
        super().__init__("Registrar Compra", 520, 780)
        self.usuario = usuario
        self.on_guardar = on_guardar
        self.productos = ProductoRepository.obtener_todos()
        self.mapa = {f"{p.codigo} - {p.nombre}": p for p in self.productos}
        self._crear_contenido(producto_id)

    def _crear_contenido(self, producto_id):
        if not self.productos:
            ctk.CTkLabel(self, text="Primero agrega productos al inventario.").pack(pady=40)
            return
        ctk.CTkButton(self, text="Guardar Compra", command=self._guardar, fg_color=Color.EXITO, hover_color=Color.EXITO_HOVER,
                      font=ctk.CTkFont(size=16, weight="bold"), height=45).pack(side="bottom", fill="x", padx=20, pady=15)
        frame = ctk.CTkScrollableFrame(self, fg_color="transparent")
        frame.pack(fill="both", expand=True, padx=20, pady=(20, 0))

        etiquetas = list(self.mapa.keys())
        inicial = next((k for k, p in self.mapa.items() if p.id == producto_id), etiquetas[0])
        self.prod_var = ctk.StringVar(value=inicial)
        self.fecha_var = ctk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))
        self.cant_var = ctk.StringVar(value="1")
        self.costo_var = ctk.StringVar()
        self.proveedor_var = ctk.StringVar()
        self.nota_var = ctk.StringVar()
        self.precio_var = ctk.StringVar()

        ctk.CTkLabel(frame, text="Producto:", font=ctk.CTkFont(size=14)).pack(anchor="w")
        ctk.CTkComboBox(frame, variable=self.prod_var, values=etiquetas, font=ctk.CTkFont(size=14), height=35,
                        command=lambda v: self._producto_cambio()).pack(fill="x", pady=(0, 10))
        self.lbl_stock = ctk.CTkLabel(frame, text="", font=ctk.CTkFont(size=12), text_color=Color.TEXTO_SUAVE, justify="left")
        self.lbl_stock.pack(anchor="w", pady=(0, 10))

        crear_campo(frame, "Fecha de la compra (AAAA-MM-DD):", self.fecha_var)
        crear_campo(frame, "Cantidad comprada:", self.cant_var, numerico=True)
        crear_campo(frame, f"Costo por unidad/kg ({MONEDA}):", self.costo_var, numerico=True)
        crear_campo(frame, "Proveedor (opcional):", self.proveedor_var)
        crear_campo(frame, "Nota (opcional):", self.nota_var)
        crear_campo(frame, f"Precio de venta ({MONEDA}) - cámbialo si quieres actualizarlo:", self.precio_var, numerico=True)

        self.lbl_info = ctk.CTkLabel(frame, text="", font=ctk.CTkFont(size=14, weight="bold"), justify="left")
        self.lbl_info.pack(anchor="w", pady=10)

        for v in (self.cant_var, self.costo_var, self.precio_var):
            v.trace_add("write", self._refrescar)
        self._producto_cambio()

    def _producto_actual(self):
        return self.mapa.get(self.prod_var.get())

    def _producto_cambio(self):
        p = self._producto_actual()
        if not p:
            return
        self.precio_var.set(numero_a_texto(p.precio))
        self.lbl_stock.configure(text=f"Stock actual: {p.stock:g} {p.unidad}   |   Costo actual: {MONEDA}{(p.costo or 0):.2f}   |   Precio actual: {MONEDA}{p.precio:.2f}")
        self._refrescar()

    def _refrescar(self, *args):
        p = self._producto_actual()
        try:
            cant = parse_decimal(self.cant_var.get())
            costo = parse_decimal(self.costo_var.get())
            precio = parse_decimal(self.precio_var.get())
        except ValueError:
            self.lbl_info.configure(text="")
            return
        stock = max(p.stock or 0, 0)
        base = stock + cant
        costo_prom = (stock * (p.costo or 0) + cant * costo) / base if base > 0 else costo
        ganancia = precio - costo_prom
        margen = ganancia / precio * 100 if precio > 0 else 0
        self.lbl_info.configure(
            text=(f"Total de la compra: {MONEDA}{cant * costo:,.2f}\n"
                  f"Costo promedio nuevo: {MONEDA}{costo_prom:.2f} por {p.unidad}\n"
                  f"Ganancia por {p.unidad}: {MONEDA}{ganancia:.2f}  (margen {margen:.0f}%)\n"
                  f"Stock quedaría en: {(p.stock or 0) + cant:g} {p.unidad}"),
            text_color=Color.EXITO if ganancia > 0 else Color.PELIGRO)

    def _guardar(self):
        p = self._producto_actual()
        try:
            cant = parse_decimal(self.cant_var.get())
            costo = parse_decimal(self.costo_var.get())
            precio = parse_decimal(self.precio_var.get())
            fecha = datetime.strptime(self.fecha_var.get().strip(), "%Y-%m-%d").strftime("%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Error", "Revisa la fecha (AAAA-MM-DD) y que cantidad, costo y precio sean números.", parent=self)
            return
        if cant <= 0 or costo <= 0:
            messagebox.showwarning("Atención", "La cantidad y el costo deben ser mayores que 0.", parent=self)
            return
        if precio <= costo and not messagebox.askyesno("Sin ganancia", "El precio de venta es menor o igual al costo: no ganarías nada (o perderías).\n¿Guardar de todos modos?", parent=self):
            return
        nuevo_precio = precio if abs(precio - p.precio) > 1e-9 else None
        ok, msg = CompraRepository.registrar(p.id, cant, costo, fecha, self.proveedor_var.get().strip(), self.nota_var.get().strip(), self.usuario, nuevo_precio)
        if ok:
            messagebox.showinfo("Éxito", msg, parent=self)
            self.destroy()
            if self.on_guardar:
                self.on_guardar()
        else:
            messagebox.showerror("Error", msg, parent=self)


class UsuarioDialog(DialogoBase):
    def __init__(self, parent, on_guardar=None):
        super().__init__("Agregar Usuario", 400, 350)
        self.on_guardar = on_guardar
        self._crear_contenido()

    def _crear_contenido(self):
        frame = ctk.CTkFrame(self, fg_color="transparent")
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        ctk.CTkLabel(frame, text="Usuario:", font=ctk.CTkFont(size=14)).pack(anchor="w")
        self.usuario_var = ctk.StringVar()
        ctk.CTkEntry(frame, textvariable=self.usuario_var, font=ctk.CTkFont(size=14),
                     height=35).pack(fill="x", pady=(0, 10))

        ctk.CTkLabel(frame, text="Contraseña:", font=ctk.CTkFont(size=14)).pack(anchor="w")
        self.clave_var = ctk.StringVar()
        ctk.CTkEntry(frame, textvariable=self.clave_var, show="*", font=ctk.CTkFont(size=14),
                     height=35).pack(fill="x", pady=(0, 10))

        ctk.CTkLabel(frame, text="Rol:", font=ctk.CTkFont(size=14)).pack(anchor="w")
        self.rol_var = ctk.StringVar(value="trabajador")
        ctk.CTkOptionMenu(frame, variable=self.rol_var, values=["admin", "duena", "trabajador"],
                          font=ctk.CTkFont(size=14)).pack(fill="x", pady=(0, 10))

        ctk.CTkLabel(frame, text="Nombre completo:", font=ctk.CTkFont(size=14)).pack(anchor="w")
        self.nombre_var = ctk.StringVar()
        ctk.CTkEntry(frame, textvariable=self.nombre_var, font=ctk.CTkFont(size=14),
                     height=35).pack(fill="x", pady=(0, 10))

        ctk.CTkButton(frame, text="Guardar", command=self._guardar,
                      fg_color=Color.PRIMARIO, hover_color=Color.PRIMARIO_HOVER,
                      font=ctk.CTkFont(size=16, weight="bold"), height=45).pack(fill="x", pady=10)

    def _guardar(self):
        usuario = self.usuario_var.get().strip()
        clave = self.clave_var.get().strip()
        rol = self.rol_var.get()
        nombre = self.nombre_var.get().strip()

        if not usuario or not clave:
            messagebox.showwarning("Atención", "Usuario y contraseña son obligatorios.")
            return

        ok, msg = UsuarioRepository.agregar(usuario, clave, rol, nombre)
        if ok:
            messagebox.showinfo("Éxito", msg)
            self.destroy()
            if self.on_guardar:
                self.on_guardar()
        else:
            messagebox.showerror("Error", msg)


class BoletaDialog(DialogoBase):
    def __init__(self, parent, numero, total, vuelto, items, usuario):
        super().__init__(f"Boleta {numero}", 400, 500)
        self._crear_contenido(numero, total, vuelto, items, usuario)

    def _crear_contenido(self, numero, total, vuelto, items, usuario):
        texto = ctk.CTkTextbox(self, font=("Courier New", 12))
        texto.pack(fill="both", expand=True, padx=10, pady=10)

        config = ConfigRepository.obtener()
        lineas = []
        lineas.append("=" * 35)
        lineas.append(f"{config.get('nombre', 'Mi Tienda'):^35}")
        if config.get("rut"):
            lineas.append(f"RUT: {config['rut']}")
        if config.get("direccion"):
            lineas.append(config["direccion"])
        lineas.append("=" * 35)
        lineas.append(f"BOLETA: {numero}")
        lineas.append(f"Fecha: {datetime.now().strftime('%d/%m/%Y %H:%M')}")
        lineas.append(f"Cajero: {usuario}")
        lineas.append("-" * 35)

        for item in items:
            lineas.append(f"{item['nombre'][:15]:<15} x{item['cantidad']:<5g} {MONEDA}{item['subtotal']:>7.2f}")

        lineas.append("-" * 35)
        lineas.append(f"{'TOTAL:':<25}{MONEDA}{total:>7.2f}")
        lineas.append("=" * 35)
        lineas.append(f"{'¡GRACIAS POR SU COMPRA!':^35}")

        texto.insert("1.0", "\n".join(lineas))
        texto.configure(state="disabled")

        ctk.CTkButton(self, text="Cerrar", command=self.destroy,
                      fg_color=Color.PRIMARIO, hover_color=Color.PRIMARIO_HOVER,
                      font=ctk.CTkFont(size=16, weight="bold"), height=45).pack(pady=10, padx=10, fill="x")
