"""Conexión y creación/migración de la base de datos SQLite."""
import sqlite3

from src import config
from src.config import CATEGORIAS_DEFECTO, USUARIOS_DEFECTO
from src.security import esta_hasheada, hashear_clave


def conectar() -> sqlite3.Connection:
    conn = sqlite3.connect(config.DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.row_factory = sqlite3.Row
    return conn


class Database:
    def __init__(self):
        self.inicializar()

    def inicializar(self):
        conn = conectar()
        c = conn.cursor()
        c.execute("CREATE TABLE IF NOT EXISTS config (clave TEXT PRIMARY KEY, valor TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS usuarios (id INTEGER PRIMARY KEY AUTOINCREMENT, usuario TEXT UNIQUE NOT NULL, clave TEXT NOT NULL, rol TEXT NOT NULL, nombre TEXT DEFAULT '')")
        c.execute("CREATE TABLE IF NOT EXISTS licencia (id INTEGER PRIMARY KEY, fecha_vencimiento TEXT, activa INTEGER DEFAULT 0)")
        c.execute("CREATE TABLE IF NOT EXISTS categorias (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT UNIQUE NOT NULL)")
        c.execute("CREATE TABLE IF NOT EXISTS productos (id INTEGER PRIMARY KEY AUTOINCREMENT, codigo TEXT UNIQUE NOT NULL, barcode TEXT DEFAULT '', nombre TEXT NOT NULL, categoria TEXT DEFAULT 'General', precio REAL NOT NULL, stock INTEGER NOT NULL DEFAULT 0)")
        c.execute("CREATE TABLE IF NOT EXISTS ventas (id INTEGER PRIMARY KEY AUTOINCREMENT, numero_boleta TEXT UNIQUE NOT NULL, fecha TEXT NOT NULL, total REAL NOT NULL, metodo_pago TEXT DEFAULT 'Efectivo', vuelto REAL DEFAULT 0, usuario TEXT DEFAULT '')")
        c.execute("CREATE TABLE IF NOT EXISTS detalle_venta (id INTEGER PRIMARY KEY AUTOINCREMENT, venta_id INTEGER NOT NULL, producto_id INTEGER NOT NULL, cantidad INTEGER NOT NULL, precio_unitario REAL NOT NULL, subtotal REAL NOT NULL, FOREIGN KEY (venta_id) REFERENCES ventas(id), FOREIGN KEY (producto_id) REFERENCES productos(id))")

        c.execute("CREATE TABLE IF NOT EXISTS compras (id INTEGER PRIMARY KEY AUTOINCREMENT, fecha TEXT NOT NULL, producto_id INTEGER NOT NULL, cantidad REAL NOT NULL, costo_unitario REAL NOT NULL, total REAL NOT NULL, proveedor TEXT DEFAULT '', nota TEXT DEFAULT '', usuario TEXT DEFAULT '', FOREIGN KEY (producto_id) REFERENCES productos(id))")

        # Migración: agrega columnas nuevas a bases de datos ya existentes (no borra nada)
        for tabla, col, ddl in [("productos", "costo", "REAL DEFAULT 0"),
                                ("productos", "unidad", "TEXT DEFAULT 'unidad'"),
                                ("productos", "stock_minimo", "REAL DEFAULT 5"),
                                ("detalle_venta", "costo_unitario", "REAL DEFAULT 0")]:
            existentes = [r[1] for r in c.execute(f"PRAGMA table_info({tabla})").fetchall()]
            if col not in existentes:
                c.execute(f"ALTER TABLE {tabla} ADD COLUMN {col} {ddl}")

        defaults = [("nombre", "Tienda Rápida"), ("rut", ""), ("direccion", ""), ("telefono", ""), ("numero_boleta", "1")]
        for clave, valor in defaults:
            c.execute("INSERT OR IGNORE INTO config (clave, valor) VALUES (?, ?)", (clave, valor))

        for usuario, clave, rol, nombre in USUARIOS_DEFECTO:
            if not c.execute("SELECT 1 FROM usuarios WHERE usuario = ?", (usuario,)).fetchone():
                c.execute("INSERT INTO usuarios (usuario, clave, rol, nombre) VALUES (?, ?, ?, ?)", (usuario, hashear_clave(clave), rol, nombre))

        # Migración: contraseñas que estaban en texto plano pasan a guardarse con hash
        for fila in c.execute("SELECT id, clave FROM usuarios").fetchall():
            if not esta_hasheada(fila["clave"]):
                c.execute("UPDATE usuarios SET clave = ? WHERE id = ?", (hashear_clave(fila["clave"]), fila["id"]))

        c.execute("INSERT OR IGNORE INTO licencia (id, fecha_vencimiento, activa) VALUES (1, '2020-01-01', 0)")

        for cat in CATEGORIAS_DEFECTO:
            c.execute("INSERT OR IGNORE INTO categorias (nombre) VALUES (?)", (cat,))

        c.execute("SELECT COUNT(*) FROM productos")
        if c.fetchone()[0] == 0:
            ejemplos = [("P001", "7801234567890", "Gaseosa 500ml", "Bebidas", 15.0, 50), ("P002", "7801234567891", "Agua Mineral 1L", "Bebidas", 10.0, 100), ("P003", "7801234567892", "Papas Fritas", "Snacks", 12.0, 30), ("P004", "7801234567893", "Chocolate", "Snacks", 8.0, 40), ("P005", "7801234567894", "Sandwich", "Comida", 25.0, 20), ("P006", "7801234567895", "Café", "Comida", 18.0, 25), ("P007", "7801234567896", "Pan", "Panadería", 5.0, 60), ("P008", "7801234567897", "Leche 1L", "Lácteos", 12.0, 35)]
            for p in ejemplos:
                c.execute("INSERT OR IGNORE INTO productos (codigo, barcode, nombre, categoria, precio, stock) VALUES (?, ?, ?, ?, ?, ?)", p)

        conn.commit()
        conn.close()
