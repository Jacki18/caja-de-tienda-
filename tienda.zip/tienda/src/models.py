"""Modelos de datos."""
from typing import NamedTuple


class Producto(NamedTuple):
    """Fila de la tabla productos. Se accede por nombre (p.precio) en vez de por posición (p[5])."""
    id: int
    codigo: str
    barcode: str
    nombre: str
    categoria: str
    precio: float
    stock: float
    unidad: str
    costo: float
    stock_minimo: float
