"""Funciones auxiliares sin dependencias de la interfaz."""
import math


def parse_decimal(texto, vacio=None) -> float:
    """Convierte texto a número aceptando coma o punto decimal ("4,5" y "4.5").

    Si el texto está vacío devuelve `vacio` (si se indicó) o lanza ValueError.
    """
    limpio = (texto or "").strip().replace(",", ".")
    if not limpio:
        if vacio is not None:
            return vacio
        raise ValueError("valor vacío")
    valor = float(limpio)
    if not math.isfinite(valor):
        raise ValueError("número inválido")
    return valor


def numero_a_texto(valor) -> str:
    """4.5 -> '4.5', 12.0 -> '12', 0 -> '0' (sin ceros ni notación científica)."""
    return (f"{float(valor or 0):.4f}".rstrip("0").rstrip(".")) or "0"
