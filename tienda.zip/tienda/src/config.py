"""Constantes y configuración global de TiendaPro."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
ASSETS_DIR = BASE_DIR / "assets"
# La ruta de la base de datos se puede cambiar con la variable de entorno TIENDA_DB (útil para pruebas)
DB_PATH = Path(os.environ.get("TIENDA_DB", BASE_DIR / "tienda_pro.db"))

APP_ID = "TiendaPro.PuntoDeVenta"   # identidad en la barra de tareas de Windows
MONEDA = "S/"
UNIDADES = ["unidad", "kg", "litro", "paquete", "docena"]
STOCK_MINIMO_DEFECTO = 5

ROLES = {
    "admin": {"nombre": "Admin General", "permisos": ["todo"]},
    "duena": {"nombre": "Dueña", "permisos": ["venta", "inventario", "agregar_producto", "eliminar_producto", "compras", "ver_costos", "reportes"]},
    "trabajador": {"nombre": "Trabajador", "permisos": ["venta", "agregar_producto"]},
}
# Permisos de Admin y Dueña únicamente:
#   compras    -> registrar compras/reposición y ver su historial
#   ver_costos -> ver y editar el costo de los productos y la ganancia por producto
#   reportes   -> pestaña Ganancias y columna de ganancia en el historial

USUARIOS_DEFECTO = [
    ("admin", "admin123", "admin", "Admin General"),
    ("duena", "duena123", "duena", "Dueña"),
    ("trabajador", "trabaja123", "trabajador", "Trabajador"),
]
CATEGORIAS_DEFECTO = ["General", "Bebidas", "Snacks", "Comida", "Frutas", "Lácteos", "Panadería", "Limpieza", "Otros"]


class Color:
    """Paleta de la interfaz (tema oscuro)."""
    PRIMARIO = "#3b82f6"
    PRIMARIO_HOVER = "#2563eb"
    SUPERFICIE = "#1e293b"
    BORDE = "#334155"
    FONDO_INPUT = "#0f172a"
    TEXTO = "#f1f5f9"
    TEXTO_SUAVE = "#94a3b8"
    EXITO = "#22c55e"
    EXITO_HOVER = "#16a34a"
    PELIGRO = "#ef4444"
    PELIGRO_HOVER = "#b91c1c"
    PELIGRO_SUAVE = "#f87171"
    AMBAR = "#fbbf24"
    GRIS = "#475569"
    GRIS_HOVER = "#64748b"
    COBRAR = "#2b8a3e"
    COBRAR_HOVER = "#237032"
    SOL = "#f59e0b"
    SOL_HOVER = "#d97706"
    ROJO_CLARO = "#fee2e2"
    ROJO_CLARO_HOVER = "#fecaca"
    AMBAR_CLARO = "#fef3c7"
    AMBAR_CLARO_HOVER = "#fde68a"
    AMBAR_OSCURO = "#292524"
    AMBAR_OSCURO_HOVER = "#44403c"
