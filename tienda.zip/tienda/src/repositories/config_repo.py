"""Acceso a datos: configuración del negocio."""
from src.database import conectar


class ConfigRepository:
    @staticmethod
    def obtener():
        conn = conectar()
        c = conn.cursor()
        c.execute("SELECT clave, valor FROM config")
        config = {r[0]: r[1] for r in c.fetchall()}
        conn.close()
        return config

    @staticmethod
    def guardar(clave, valor):
        conn = conectar()
        c = conn.cursor()
        c.execute("UPDATE config SET valor = ? WHERE clave = ?", (valor, clave))
        conn.commit()
        conn.close()
