"""Acceso a datos: productos."""
import random
import sqlite3
from datetime import datetime

from src.database import conectar
from src.models import Producto


COLS_PRODUCTO = "id, codigo, barcode, nombre, categoria, precio, stock, unidad, costo, stock_minimo"


class ProductoRepository:
    @staticmethod
    def obtener_todos(filtro=""):
        conn = conectar()
        c = conn.cursor()
        if filtro:
            like = f"%{filtro}%"
            c.execute(f"SELECT {COLS_PRODUCTO} FROM productos WHERE nombre LIKE ? OR codigo LIKE ? OR barcode LIKE ? ORDER BY categoria, nombre", (like, like, like))
        else:
            c.execute(f"SELECT {COLS_PRODUCTO} FROM productos ORDER BY categoria, nombre")
        productos = [Producto(*fila) for fila in c.fetchall()]
        conn.close()
        return productos

    @staticmethod
    def obtener_por_id(id_p):
        conn = conectar()
        c = conn.cursor()
        c.execute(f"SELECT {COLS_PRODUCTO} FROM productos WHERE id = ?", (id_p,))
        fila = c.fetchone()
        conn.close()
        return Producto(*fila) if fila else None

    @staticmethod
    def obtener_por_codigo(texto):
        """Busca coincidencia exacta por código o código de barras (lector de barras)."""
        conn = conectar()
        c = conn.cursor()
        c.execute(f"SELECT {COLS_PRODUCTO} FROM productos WHERE codigo = ? OR barcode = ?", (texto, texto))
        fila = c.fetchone()
        conn.close()
        return Producto(*fila) if fila else None

    @staticmethod
    def agregar(codigo, barcode, nombre, categoria, precio, stock, unidad="unidad", costo=0.0, stock_minimo=5, usuario=""):
        conn = conectar()
        c = conn.cursor()
        try:
            c.execute("SELECT COUNT(*) FROM productos WHERE codigo = ?", (codigo,))
            if c.fetchone()[0] > 0:
                return False, f"El código '{codigo}' ya existe."
            c.execute("INSERT INTO productos (codigo, barcode, nombre, categoria, precio, stock, unidad, costo, stock_minimo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                      (codigo, barcode, nombre, categoria, precio, stock, unidad, costo, stock_minimo))
            producto_id = c.lastrowid
            if stock > 0:
                # El stock inicial queda registrado en el historial de compras
                c.execute("INSERT INTO compras (fecha, producto_id, cantidad, costo_unitario, total, proveedor, nota, usuario) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                          (datetime.now().strftime("%Y-%m-%d"), producto_id, stock, costo, round(stock * costo, 2), "", "Stock inicial", usuario))
            conn.commit()
            return True, "Producto agregado."
        except Exception as e:
            conn.rollback()
            return False, f"Error: {str(e)}"
        finally:
            conn.close()

    @staticmethod
    def actualizar(id_p, codigo, barcode, nombre, categoria, precio, stock, unidad="unidad", costo=0.0, stock_minimo=5):
        conn = conectar()
        c = conn.cursor()
        try:
            c.execute("UPDATE productos SET codigo=?, barcode=?, nombre=?, categoria=?, precio=?, stock=?, unidad=?, costo=?, stock_minimo=? WHERE id=?",
                      (codigo, barcode, nombre, categoria, precio, stock, unidad, costo, stock_minimo, id_p))
            conn.commit()
            return True, "Producto actualizado."
        except sqlite3.IntegrityError:
            return False, "Ya existe otro producto con ese código."
        except Exception as e:
            return False, f"Error: {str(e)}"
        finally:
            conn.close()

    @staticmethod
    def eliminar(id_p):
        conn = conectar()
        c = conn.cursor()
        try:
            c.execute("DELETE FROM productos WHERE id = ?", (id_p,))
            conn.commit()
            return True, "Producto eliminado."
        except sqlite3.IntegrityError:
            conn.rollback()
            return False, "Este producto ya tiene ventas o compras registradas, así que no se puede eliminar sin perder el historial.\nPuedes dejarlo en stock 0."
        finally:
            conn.close()

    @staticmethod
    def generar_codigo_automatico():
        productos = ProductoRepository.obtener_todos()
        numero = len(productos) + 1
        while any(p.codigo == f"P{numero:03d}" for p in productos):
            numero += 1
        return f"P{numero:03d}"

    @staticmethod
    def generar_barcode():
        codigo = "780"
        for _ in range(9):
            codigo += str(random.randint(0, 9))
        suma = sum(int(codigo[i]) * (1 if i % 2 == 0 else 3) for i in range(12))
        return codigo + str((10 - (suma % 10)) % 10)
