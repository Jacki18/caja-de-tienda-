"""Acceso a datos: usuarios."""
import sqlite3
from contextlib import closing

from src.database import conectar
from src.security import hashear_clave, verificar_clave


class UsuarioRepository:
    @staticmethod
    def login(usuario, clave):
        with closing(conectar()) as conn:
            row = conn.execute("SELECT usuario, rol, nombre, clave FROM usuarios WHERE usuario = ?", (usuario,)).fetchone()
        if row and verificar_clave(clave, row["clave"]):
            return {"usuario": row["usuario"], "rol": row["rol"], "nombre": row["nombre"]}
        return None

    @staticmethod
    def obtener_todos():
        with closing(conectar()) as conn:
            return conn.execute("SELECT usuario, rol, nombre FROM usuarios").fetchall()

    @staticmethod
    def agregar(usuario, clave, rol, nombre):
        with closing(conectar()) as conn:
            try:
                conn.execute("INSERT INTO usuarios (usuario, clave, rol, nombre) VALUES (?, ?, ?, ?)",
                             (usuario, hashear_clave(clave), rol, nombre))
                conn.commit()
                return True, "Usuario agregado."
            except sqlite3.IntegrityError:
                return False, "Ya existe un usuario con ese nombre."

    @staticmethod
    def eliminar(usuario):
        with closing(conectar()) as conn:
            conn.execute("DELETE FROM usuarios WHERE usuario = ?", (usuario,))
            conn.commit()

    @staticmethod
    def cambiar_clave(usuario, nueva_clave):
        with closing(conectar()) as conn:
            conn.execute("UPDATE usuarios SET clave = ? WHERE usuario = ?", (hashear_clave(nueva_clave), usuario))
            conn.commit()
        return True, f"Contraseña de '{usuario}' actualizada."
