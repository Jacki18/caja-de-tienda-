"""Acceso a datos: ventas."""
from datetime import datetime

from src.database import conectar


class VentaRepository:
    @staticmethod
    def registrar(items, metodo_pago, vuelto, usuario):
        conn = conectar()
        c = conn.cursor()
        try:
            c.execute("SELECT valor FROM config WHERE clave='numero_boleta'")
            numero = int(c.fetchone()[0])
            numero_boleta = f"B{numero:06d}"
            total = round(sum(item["subtotal"] for item in items), 2)
            fecha = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            c.execute("INSERT INTO ventas (numero_boleta, fecha, total, metodo_pago, vuelto, usuario) VALUES (?, ?, ?, ?, ?, ?)", (numero_boleta, fecha, total, metodo_pago, vuelto, usuario))
            venta_id = c.lastrowid
            for item in items:
                c.execute("SELECT nombre, stock, costo FROM productos WHERE id = ?", (item["producto_id"],))
                prod = c.fetchone()
                if prod is None:
                    raise ValueError("Un producto de la venta ya no existe.")
                if (prod["stock"] or 0) < item["cantidad"] - 1e-9:
                    raise ValueError(f"Stock insuficiente de {prod['nombre']}.")
                # Se guarda el costo del momento: así la ganancia histórica no cambia si luego sube el costo
                c.execute("INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, subtotal, costo_unitario) VALUES (?, ?, ?, ?, ?, ?)",
                          (venta_id, item["producto_id"], item["cantidad"], item["precio_unitario"], item["subtotal"], prod["costo"] or 0))
                c.execute("UPDATE productos SET stock = ROUND(stock - ?, 3) WHERE id = ?", (item["cantidad"], item["producto_id"]))
            c.execute("UPDATE config SET valor = ? WHERE clave='numero_boleta'", (str(numero + 1),))
            conn.commit()
            return numero_boleta, total
        except Exception as e:
            conn.rollback()
            return None, str(e)
        finally:
            conn.close()

    @staticmethod
    def obtener_todas():
        conn = conectar()
        c = conn.cursor()
        c.execute("""SELECT v.id, v.numero_boleta, v.fecha, v.total, v.metodo_pago, v.vuelto, v.usuario,
                            COALESCE((SELECT SUM((d.precio_unitario - d.costo_unitario) * d.cantidad)
                                      FROM detalle_venta d WHERE d.venta_id = v.id), 0) AS ganancia
                     FROM ventas v ORDER BY v.id DESC""")
        ventas = c.fetchall()
        conn.close()
        return ventas

    @staticmethod
    def obtener_detalle(venta_id):
        conn = conectar()
        c = conn.cursor()
        c.execute("SELECT p.nombre, d.cantidad, d.precio_unitario, d.subtotal FROM detalle_venta d JOIN productos p ON d.producto_id = p.id WHERE d.venta_id = ?", (venta_id,))
        detalle = c.fetchall()
        conn.close()
        return detalle
