"""Acceso a datos: licencia del sistema."""
from datetime import datetime, timedelta

from src.database import conectar


class LicenciaRepository:
    @staticmethod
    def verificar():
        conn = conectar()
        c = conn.cursor()
        c.execute("SELECT fecha_vencimiento, activa FROM licencia WHERE id = 1")
        row = c.fetchone()
        conn.close()
        if not row:
            return False, "Sin licencia"
        fecha_venc = datetime.strptime(row[0], "%Y-%m-%d")
        dias_restantes = (fecha_venc - datetime.now()).days
        if dias_restantes > 0 and row[1]:
            return True, f"Vigente ({dias_restantes} días)"
        return False, "Licencia vencida"

    @staticmethod
    def activar(meses):
        fecha_venc = datetime.now() + timedelta(days=meses * 30)
        conn = conectar()
        c = conn.cursor()
        c.execute("UPDATE licencia SET fecha_vencimiento = ?, activa = 1 WHERE id = 1", (fecha_venc.strftime("%Y-%m-%d"),))
        conn.commit()
        conn.close()
        return fecha_venc
