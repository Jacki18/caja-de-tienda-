"""Acceso a datos: reportes de ganancias y alertas."""
from src.database import conectar


class ReporteRepository:
    @staticmethod
    def ganancias(desde, hasta):
        """Por producto: (nombre, unidad, cantidad, ingresos, costo, ganancia)"""
        conn = conectar()
        c = conn.cursor()
        c.execute("""SELECT p.nombre, p.unidad, SUM(d.cantidad), SUM(d.subtotal),
                            SUM(d.costo_unitario * d.cantidad), SUM(d.subtotal - d.costo_unitario * d.cantidad)
                     FROM detalle_venta d
                     JOIN ventas v ON v.id = d.venta_id
                     JOIN productos p ON p.id = d.producto_id
                     WHERE date(v.fecha) BETWEEN ? AND ?
                     GROUP BY p.id ORDER BY 6 DESC""", (desde, hasta))
        filas = c.fetchall()
        conn.close()
        return filas

    @staticmethod
    def total_compras(desde, hasta):
        conn = conectar()
        c = conn.cursor()
        c.execute("SELECT COALESCE(SUM(total), 0) FROM compras WHERE fecha BETWEEN ? AND ?", (desde, hasta))
        total = c.fetchone()[0]
        conn.close()
        return total

    @staticmethod
    def alertas():
        conn = conectar()
        c = conn.cursor()
        c.execute("SELECT nombre, stock, unidad, stock_minimo FROM productos WHERE stock <= COALESCE(stock_minimo, 5) ORDER BY stock")
        bajo = c.fetchall()
        c.execute("SELECT nombre FROM productos WHERE costo IS NULL OR costo <= 0 ORDER BY nombre")
        sin_costo = [r[0] for r in c.fetchall()]
        c.execute("SELECT nombre, precio, costo FROM productos WHERE costo > 0 AND precio <= costo ORDER BY nombre")
        sin_ganancia = c.fetchall()
        conn.close()
        return {"bajo": bajo, "sin_costo": sin_costo, "sin_ganancia": sin_ganancia}
