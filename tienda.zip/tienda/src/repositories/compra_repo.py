"""Acceso a datos: compras de mercadería."""
from src.database import conectar


class CompraRepository:
    @staticmethod
    def registrar(producto_id, cantidad, costo_unitario, fecha, proveedor="", nota="", usuario="", nuevo_precio=None):
        """Registra una compra, suma el stock y recalcula el costo promedio ponderado."""
        conn = conectar()
        c = conn.cursor()
        try:
            c.execute("SELECT stock, costo FROM productos WHERE id = ?", (producto_id,))
            row = c.fetchone()
            if row is None:
                return False, "El producto no existe."
            stock_actual = row["stock"] or 0
            costo_actual = row["costo"] or 0
            base = max(stock_actual, 0) + cantidad
            costo_prom = (max(stock_actual, 0) * costo_actual + cantidad * costo_unitario) / base if base > 0 else costo_unitario
            c.execute("INSERT INTO compras (fecha, producto_id, cantidad, costo_unitario, total, proveedor, nota, usuario) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                      (fecha, producto_id, cantidad, costo_unitario, round(cantidad * costo_unitario, 2), proveedor, nota, usuario))
            c.execute("UPDATE productos SET stock = ROUND(stock + ?, 3), costo = ? WHERE id = ?", (cantidad, round(costo_prom, 4), producto_id))
            if nuevo_precio is not None:
                c.execute("UPDATE productos SET precio = ? WHERE id = ?", (nuevo_precio, producto_id))
            conn.commit()
            return True, "Compra registrada."
        except Exception as e:
            conn.rollback()
            return False, f"Error: {str(e)}"
        finally:
            conn.close()

    @staticmethod
    def obtener(filtro=""):
        conn = conectar()
        c = conn.cursor()
        sql = ("SELECT c.id, c.fecha, p.nombre, p.unidad, c.cantidad, c.costo_unitario, c.total, c.proveedor, c.usuario, c.nota "
               "FROM compras c JOIN productos p ON p.id = c.producto_id ")
        if filtro:
            like = f"%{filtro}%"
            c.execute(sql + "WHERE p.nombre LIKE ? OR c.proveedor LIKE ? ORDER BY c.fecha DESC, c.id DESC", (like, like))
        else:
            c.execute(sql + "ORDER BY c.fecha DESC, c.id DESC")
        filas = c.fetchall()
        conn.close()
        return filas
