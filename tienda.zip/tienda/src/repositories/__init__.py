from .compra_repo import CompraRepository
from .config_repo import ConfigRepository
from .licencia_repo import LicenciaRepository
from .producto_repo import ProductoRepository
from .reporte_repo import ReporteRepository
from .usuario_repo import UsuarioRepository
from .venta_repo import VentaRepository

__all__ = ["CompraRepository", "ConfigRepository", "LicenciaRepository", "ProductoRepository",
           "ReporteRepository", "UsuarioRepository", "VentaRepository"]
