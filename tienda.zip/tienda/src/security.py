"""Manejo seguro de contraseñas (PBKDF2-HMAC-SHA256 con sal aleatoria)."""
import hashlib
import hmac
import os

_PREFIJO = "pbkdf2"
_ITERACIONES = 200_000


def esta_hasheada(valor: str) -> bool:
    return isinstance(valor, str) and valor.startswith(_PREFIJO + "$")


def hashear_clave(clave: str) -> str:
    sal = os.urandom(16)
    derivada = hashlib.pbkdf2_hmac("sha256", clave.encode("utf-8"), sal, _ITERACIONES)
    return f"{_PREFIJO}${_ITERACIONES}${sal.hex()}${derivada.hex()}"


def verificar_clave(clave: str, guardada: str) -> bool:
    if not esta_hasheada(guardada):          # compatibilidad con bases antiguas (texto plano)
        return hmac.compare_digest(clave.encode("utf-8"), (guardada or "").encode("utf-8"))
    try:
        _, iteraciones, sal, esperada = guardada.split("$")
        derivada = hashlib.pbkdf2_hmac("sha256", clave.encode("utf-8"), bytes.fromhex(sal), int(iteraciones))
        return hmac.compare_digest(derivada.hex(), esperada)
    except ValueError:
        return False
